import React from 'react';
import { Text, View, StyleSheet, Image} from 'react-native';




const  App=() => {
  return (
    <View style={{flex:1 ,justifyContent: 'center', backgroundColor: '#f3f4f4', padding: 7}} >
      <Text> 
            world hay
      </Text>
      <Image source={require('./assets/images.jpg')}/>
    
    </View>
  );
}
export default App;