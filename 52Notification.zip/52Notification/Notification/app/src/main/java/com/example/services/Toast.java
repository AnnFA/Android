package com.example.services;

import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class Toast extends AppCompatActivity {

    private static final int LONG_DELAY = 3500;

    public void showToast(View view) {
        android.widget.Toast toast3 = android.widget.Toast.makeText(getApplicationContext(),
                R.string.toast, android.widget.Toast.LENGTH_LONG);
        toast3.setGravity(Gravity.CENTER, 0, 0);
        LinearLayout toastContainer = (LinearLayout) toast3.getView();
        ImageView catImageView = new ImageView(getApplicationContext());
        catImageView.setImageResource(R.drawable.zv);
        toastContainer.addView(catImageView, 0);
        toast3.show();
    }
}
