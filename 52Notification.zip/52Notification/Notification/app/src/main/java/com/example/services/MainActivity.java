package com.example.services;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button toast;

    private static final String TAG = "my log";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Log.d(TAG, "поиск view");
        toast = (Button) findViewById(R.id.st);

        toast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast3 = Toast.makeText(MainActivity.this,
                        "Toast с изображением",
                        Toast.LENGTH_LONG);
                // Позиционирование Toast сообщения
                toast3.setGravity(Gravity.CENTER, 0, 100);
                // Создание компонента ImageView
                ImageView imgView;
                imgView = new ImageView(MainActivity.this);
                // Определение изображения
                imgView.setImageResource(R.drawable.zv);
                // Разметка интерфейса
                LinearLayout linearLayout;
                linearLayout = (LinearLayout)toast3.getView();
                // Добавление изображения в интерфейс компонента
                linearLayout.addView(imgView);
                // Представление сообщения
                toast3.show();
            }
        });

    }
}